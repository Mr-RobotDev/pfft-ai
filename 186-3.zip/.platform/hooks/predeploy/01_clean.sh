#!/usr/bin/env bash 
docker builder prune -f