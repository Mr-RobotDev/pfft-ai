

export interface APICallerOptions {
  body: object;
  URL: string;
  method: string;
}