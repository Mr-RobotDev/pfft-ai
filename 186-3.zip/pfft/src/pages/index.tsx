'use client'
import HomePage from "@/pages/home";

export default function Index() {
  return <HomePage />;
}
