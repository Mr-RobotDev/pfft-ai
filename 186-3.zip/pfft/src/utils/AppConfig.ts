// FIXME: Update this configuration file based on your project information

export const AppConfig = {
  site_name: 'PFFT.AI',
  title: 'PFFT.AI NEWS',
  description: 'Starter code for your Nextjs Boilerplate with Tailwind CSS',
  locale: 'en',
};
