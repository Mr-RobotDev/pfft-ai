/** @type {import('next-sitemap').IConfig} */
module.exports = {
  siteUrl: 'http://localhost:3000', // FIXME: Change to the production URL
  generateRobotsTxt: true,
};
